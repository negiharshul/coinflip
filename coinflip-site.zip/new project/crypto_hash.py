import hashlib
import json

def crypto_hash(*args):
    stringify = lambda data: json.dumps(data)
    stringified_args = map(stringify, args)
    sorted_strings = sorted(stringified_args)

    joined_stringified_args = ''
    for i in sorted_strings:
        joined_stringified_args += i
    encoded_string = joined_stringified_args.encode('utf-8')
    hash = hashlib.sha256(encoded_string).hexdigest()
    return hash, sorted_strings

def main():
    hashed_data1 = crypto_hash([], '3', '4')
    hashed_data2 = crypto_hash('3', [], '4')
    print(hashed_data1, hashed_data2)
    if hashed_data1 == hashed_data2:
        print("matching")
    else:
        print("not matching")


if __name__ == '__main__':
    main()

