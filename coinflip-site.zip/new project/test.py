class Block:
    def __init__(self, timestamp, last_hash, hash, data):
        self.last_hash = last_hash
        self.hash = hash
        self.data = data
    
    def __repr__(self):
        return (
            f"last_hash: {self.last_hash}, "
            f"hash: {self.hash}, "
            f"data: {self.data}"
        ) 
    @staticmethod
    def genesis_block():
        return Block('1', 'genesis_last_hash', 'genesis_hash', [])
    
        


class Blockchain:
    def __init__(self, data):
        self.chain = [Block.genesis_block()]

    def add_block(self, data):
        last_block = self.chain[-1]
